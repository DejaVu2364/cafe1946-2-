
  # 1946 Café Website Design

  This is a code bundle for 1946 Café Website Design. The original project is available at https://www.figma.com/design/i8Uh1DyL7Sp6muv2QA9Pwp/1946-Caf%C3%A9-Website-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  